package atividade01_introducao_ao_java.exericio01;

public class Exercicio01 {
	public static void main(String[] args) {
		int a = 10;
		double b = 20.5;
		boolean c = true;
		
		System.out.println("Soma de a e b: " + ( a + b ) );
		System.out.println("Multiplicação de a e b: " + ( a * b));
		System.out.println("Valor invertido de c: " + ( !c ));
		
		

	}
}
