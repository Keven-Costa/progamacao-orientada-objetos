package atividade01_introducao_ao_java.exericio02;

public class Exercicio02 {
	public static void main(String[] args) {
		Pessoa pessoa1 = new Pessoa("João", 30);
		Pessoa pessoa2 = new Pessoa("Maria", 25);
		
		pessoa1.mostrarInformacoes();
		pessoa2.mostrarInformacoes();
	}
}
